# OpenReel

A CloudStream-style Android app: one search across pluggable sources, an in-app player (Media3 ExoPlayer), and a Watching / Planned / Finished library with resume.

## Run it
1. Install Android Studio. Choose File > Open and select this folder. Let Gradle sync finish.
2. On your phone, turn on Developer options and USB debugging, plug it in, and press Run.
   Or use Build > Build APK(s) and install the APK.

## Sources
- Internet Archive: free feature films, always on.
- Jellyfin: your own server. Add its address and an API key in the Sources tab.
- This phone: pick video files in the Sources tab.

## Add a source
Write a class that implements `Provider` (see Provider.kt) and add it to the list in MainActivity.
Only add sources you have the right to stream.

## Not in this version
Movies only (no episode lists yet).
