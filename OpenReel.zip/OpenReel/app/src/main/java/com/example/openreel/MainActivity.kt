package com.example.openreel

import android.content.SharedPreferences
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("openreel", MODE_PRIVATE)
        val local = LocalProvider(this, prefs)
        // To add a source, write a class that implements Provider and add it to this list.
        val providers = listOf(ArchiveProvider(), JellyfinProvider(prefs), local)
        val tracker = Tracker(prefs)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) { App(providers, local, tracker, prefs) }
            }
        }
    }
}

fun fmt(ms: Long): String {
    val s = ms / 1000
    return "%d:%02d:%02d".format(s / 3600, s % 3600 / 60, s % 60)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(providers: List<Provider>, local: LocalProvider, tracker: Tracker, prefs: SharedPreferences) {
    val scope = rememberCoroutineScope()
    val snack = remember { SnackbarHostState() }
    var tab by remember { mutableIntStateOf(0) }
    var rev by remember { mutableIntStateOf(0) }
    var nowPlaying by remember { mutableStateOf<Triple<Title, String, Long>?>(null) }
    val labels = providers.associate { it.id to it.label }

    fun play(t: Title) {
        scope.launch {
            val url = try {
                providers.firstOrNull { it.id == t.provider && it.enabled }?.streamUrl(t)
            } catch (e: Exception) {
                null
            }
            if (url == null) {
                snack.showSnackbar("Couldn’t open ${t.name}. Check that its source is available.")
                return@launch
            }
            val old = tracker.all().firstOrNull { it.title.id == t.id && it.title.provider == t.provider }
            val start = if (old == null || old.status == Status.FINISHED) 0L else old.positionMs
            tracker.set(t, Status.WATCHING, start)
            rev++
            nowPlaying = Triple(t, url, start)
        }
    }

    fun plan(t: Title) {
        if (tracker.all().none { it.title.id == t.id && it.title.provider == t.provider }) {
            tracker.set(t, Status.PLANNED)
        }
        rev++
        scope.launch { snack.showSnackbar("Saved to Planned") }
    }

    val np = nowPlaying
    if (np != null) {
        VideoScreen(np.second, np.third) { pos, done ->
            tracker.set(np.first, if (done) Status.FINISHED else Status.WATCHING, if (done) 0L else pos)
            nowPlaying = null
            rev++
        }
    } else {
        val tabs = listOf("Search", "Library", "Sources")
        val icons = listOf(Icons.Default.Search, Icons.Default.Favorite, Icons.Default.Settings)
        Scaffold(
            snackbarHost = { SnackbarHost(snack) },
            bottomBar = {
                NavigationBar {
                    tabs.forEachIndexed { i, label ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Icon(icons[i], contentDescription = null) },
                            label = { Text(label) },
                        )
                    }
                }
            },
        ) { pad ->
            Box(Modifier.padding(pad)) {
                when (tab) {
                    0 -> SearchTab(providers, labels, ::play, ::plan)
                    1 -> LibraryTab(tracker, rev, ::play) { rev++ }
                    else -> SourcesTab(local, prefs) { rev++ }
                }
            }
        }
    }
}

@Composable
fun VideoScreen(url: String, startMs: Long, onExit: (Long, Boolean) -> Unit) {
    val ctx = LocalContext.current
    val exo = remember {
        ExoPlayer.Builder(ctx).build().apply {
            setMediaItem(MediaItem.fromUri(url))
            prepare()
            seekTo(startMs)
            playWhenReady = true
        }
    }
    var ended by remember { mutableStateOf(false) }
    DisposableEffect(exo) {
        val l = object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED) ended = true
            }
        }
        exo.addListener(l)
        onDispose {
            exo.removeListener(l)
            exo.release()
        }
    }
    BackHandler { onExit(exo.currentPosition, ended) }
    AndroidView(
        factory = { PlayerView(it).apply { player = exo; keepScreenOn = true } },
        modifier = Modifier.fillMaxSize().background(Color.Black),
    )
}

@Composable
fun TitleRow(t: Title, sub: String, actions: @Composable RowScope.() -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        AsyncImage(
            model = t.poster,
            contentDescription = null,
            modifier = Modifier.size(width = 56.dp, height = 80.dp).background(Color(0xFF263042)),
            contentScale = ContentScale.Crop,
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(t.name, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
            if (sub.isNotBlank()) {
                Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Row(content = actions)
        }
    }
}

@Composable
fun SearchTab(
    providers: List<Provider>,
    labels: Map<String, String>,
    onPlay: (Title) -> Unit,
    onPlan: (Title) -> Unit,
) {
    var q by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<Title>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var searched by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    fun run() {
        val query = q.trim()
        if (query.isEmpty()) return
        busy = true
        error = null
        scope.launch {
            val errors = mutableListOf<String>()
            results = providers.filter { it.enabled }
                .map { p ->
                    async {
                        try {
                            p.search(query)
                        } catch (e: Exception) {
                            errors.add("${labels[p.id] ?: p.id}: ${e.message ?: e.javaClass.simpleName}")
                            emptyList<Title>()
                        }
                    }
                }
                .awaitAll().flatten()
            error = if (errors.isEmpty()) null else errors.joinToString("\n")
            busy = false
            searched = true
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        OutlinedTextField(
            value = q,
            onValueChange = { q = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            label = { Text("Search all sources") },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { run() }),
        )
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp))
        error?.let {
            Text("Search problem: $it", Modifier.padding(top = 16.dp), color = MaterialTheme.colorScheme.error)
        }
        if (!busy && results.isEmpty() && error == null) {
            Text(
                if (searched) "No results. Try a shorter part of the title."
                else "Search free films. Jellyfin and videos on this phone are optional (Sources tab).",
                Modifier.padding(top = 24.dp),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        LazyColumn {
            items(results) { t ->
                TitleRow(t, listOfNotNull(t.year, labels[t.provider]).joinToString(", ")) {
                    TextButton(onClick = { onPlay(t) }) { Text("Play") }
                    TextButton(onClick = { onPlan(t) }) { Text("Plan to watch") }
                }
            }
        }
    }
}

@Composable
fun LibraryTab(tracker: Tracker, rev: Int, onPlay: (Title) -> Unit, onChange: () -> Unit) {
    var status by remember { mutableStateOf(Status.WATCHING) }
    val entries = remember(rev, status) { tracker.all().filter { it.status == status } }
    Column(Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = status.ordinal) {
            Status.values().forEach { s ->
                Tab(selected = s == status, onClick = { status = s }, text = { Text(s.label) })
            }
        }
        if (entries.isEmpty()) {
            Text(
                "Nothing here yet. Play or plan a title from Search and it shows up here.",
                Modifier.padding(24.dp),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        LazyColumn(Modifier.padding(horizontal = 16.dp)) {
            items(entries) { e ->
                val sub = if (status == Status.WATCHING && e.positionMs > 0) "Stopped at ${fmt(e.positionMs)}" else ""
                TitleRow(e.title, sub) {
                    TextButton(onClick = { onPlay(e.title) }) {
                        Text(if (status == Status.FINISHED) "Watch again" else if (e.positionMs > 0) "Resume" else "Play")
                    }
                    if (status != Status.FINISHED) {
                        TextButton(onClick = { tracker.set(e.title, Status.FINISHED, 0L); onChange() }) { Text("Finished") }
                    }
                    TextButton(onClick = { tracker.remove(e.title); onChange() }) { Text("Remove") }
                }
            }
        }
    }
}

@Composable
fun SourcesTab(local: LocalProvider, prefs: SharedPreferences, onChange: () -> Unit) {
    var url by remember { mutableStateOf(prefs.getString("jf_url", "") ?: "") }
    var key by remember { mutableStateOf(prefs.getString("jf_key", "") ?: "") }
    var files by remember { mutableStateOf(local.files()) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris.forEach { local.add(it) }
        files = local.files()
        onChange()
    }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Internet Archive", style = MaterialTheme.typography.titleMedium)
        Text("Free feature films from the Archive’s public collection. Always on.")
        HorizontalDivider()
        Text("Your Jellyfin server", style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(
            url, { url = it }, Modifier.fillMaxWidth(), singleLine = true,
            label = { Text("Address, like http://192.168.1.20:8096") },
        )
        OutlinedTextField(key, { key = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("API key") })
        Button(onClick = {
            prefs.edit().putString("jf_url", url.trim()).putString("jf_key", key.trim()).apply()
            onChange()
        }) { Text("Save server") }
        HorizontalDivider()
        Text("Videos on this phone", style = MaterialTheme.typography.titleMedium)
        Button(onClick = { picker.launch(arrayOf("video/*")) }) { Text("Add video files") }
        files.forEach { Text(it.name) }
    }
}
