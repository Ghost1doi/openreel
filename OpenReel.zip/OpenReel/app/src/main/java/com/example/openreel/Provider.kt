package com.example.openreel

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class Title(
    val id: String,
    val name: String,
    val year: String?,
    val poster: String?,
    val provider: String,
)

/** A source of videos. Add a new class implementing this and list it in MainActivity. */
interface Provider {
    val id: String
    val label: String
    val enabled: Boolean
    suspend fun search(query: String): List<Title>
    suspend fun streamUrl(title: Title): String?
}

internal suspend fun httpGet(url: String): String = withContext(Dispatchers.IO) {
    val c = URL(url).openConnection() as HttpURLConnection
    c.connectTimeout = 15000
    c.readTimeout = 15000
    try {
        c.inputStream.bufferedReader().use { it.readText() }
    } finally {
        c.disconnect()
    }
}

internal fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")
