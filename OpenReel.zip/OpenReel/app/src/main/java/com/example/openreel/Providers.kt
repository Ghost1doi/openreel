package com.example.openreel

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.provider.OpenableColumns
import org.json.JSONArray
import org.json.JSONObject

/** Free feature films from the Internet Archive's public collection. */
class ArchiveProvider : Provider {
    override val id = "archive"
    override val label = "Internet Archive"
    override val enabled = true

    override suspend fun search(query: String): List<Title> {
        val words = query.replace(Regex("[^\\p{L}\\p{N} ]"), " ").trim()
            .split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (words.isEmpty()) return emptyList()
        val q = "title:(${words.joinToString(" AND ")}) AND mediatype:movies AND " +
            "collection:(feature_films OR silent_films OR SciFi_Horror OR film_noir)"
        val url = "https://archive.org/advancedsearch.php?q=${enc(q)}" +
            "&fl%5B%5D=identifier&fl%5B%5D=title&fl%5B%5D=year" +
            "&sort%5B%5D=downloads+desc&rows=25&output=json"
        val docs = JSONObject(httpGet(url)).getJSONObject("response").getJSONArray("docs")
        return (0 until docs.length()).map { i ->
            val d = docs.getJSONObject(i)
            val ident = d.getString("identifier")
            Title(
                ident,
                d.optString("title", ident),
                d.optString("year").ifBlank { null },
                "https://archive.org/services/img/$ident",
                id,
            )
        }
    }

    override suspend fun streamUrl(title: Title): String? {
        val files = JSONObject(httpGet("https://archive.org/metadata/${title.id}"))
            .optJSONArray("files") ?: return null
        var best: String? = null
        for (i in 0 until files.length()) {
            val f = files.getJSONObject(i)
            val name = f.optString("name")
            if (name.endsWith(".mp4", ignoreCase = true)) {
                best = name
                if (f.optString("format").contains("h.264", ignoreCase = true)) break
            }
        }
        return best?.let { "https://archive.org/download/${title.id}/${enc(it).replace("+", "%20")}" }
    }
}

/** Your own Jellyfin media server (movies). Needs the server address and an API key. */
class JellyfinProvider(private val prefs: SharedPreferences) : Provider {
    override val id = "jellyfin"
    override val label = "Your Jellyfin server"
    private val server: String get() = (prefs.getString("jf_url", "") ?: "").trimEnd('/')
    private val key: String get() = prefs.getString("jf_key", "") ?: ""
    override val enabled: Boolean get() = server.isNotBlank() && key.isNotBlank()

    override suspend fun search(query: String): List<Title> {
        val url = "$server/Items?searchTerm=${enc(query)}&IncludeItemTypes=Movie&Recursive=true&Limit=25&api_key=$key"
        val items = JSONObject(httpGet(url)).getJSONArray("Items")
        return (0 until items.length()).map { i ->
            val o = items.getJSONObject(i)
            val itemId = o.getString("Id")
            Title(
                itemId,
                o.getString("Name"),
                o.optInt("ProductionYear").takeIf { it > 0 }?.toString(),
                "$server/Items/$itemId/Images/Primary?maxHeight=300&api_key=$key",
                id,
            )
        }
    }

    override suspend fun streamUrl(title: Title): String? =
        "$server/Videos/${title.id}/stream?static=true&api_key=$key"
}

/** Video files you pick on this phone. */
class LocalProvider(private val ctx: Context, private val prefs: SharedPreferences) : Provider {
    override val id = "local"
    override val label = "This phone"
    override val enabled: Boolean get() = files().isNotEmpty()

    fun files(): List<Title> {
        val arr = JSONArray(prefs.getString("local_files", "[]"))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Title(o.getString("uri"), o.getString("name"), null, null, id)
        }
    }

    fun add(uri: Uri) {
        ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        val name = ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
        } ?: uri.lastPathSegment ?: "Video"
        val arr = JSONArray(prefs.getString("local_files", "[]"))
        arr.put(JSONObject().put("uri", uri.toString()).put("name", name.substringBeforeLast('.')))
        prefs.edit().putString("local_files", arr.toString()).apply()
    }

    override suspend fun search(query: String): List<Title> =
        files().filter { it.name.contains(query, ignoreCase = true) }

    override suspend fun streamUrl(title: Title): String? = title.id
}
