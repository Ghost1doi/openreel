package com.example.openreel

import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

enum class Status(val label: String) {
    WATCHING("Watching"),
    PLANNED("Planned"),
    FINISHED("Finished"),
}

data class Entry(val title: Title, val status: Status, val positionMs: Long = 0L)

class Tracker(private val prefs: SharedPreferences) {
    fun all(): List<Entry> {
        val arr = JSONArray(prefs.getString("tracker", "[]"))
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Entry(
                Title(
                    o.getString("id"),
                    o.getString("name"),
                    o.optString("year").ifBlank { null },
                    o.optString("poster").ifBlank { null },
                    o.getString("provider"),
                ),
                Status.valueOf(o.getString("status")),
                o.optLong("pos"),
            )
        }
    }

    private fun save(list: List<Entry>) {
        val arr = JSONArray()
        list.forEach { e ->
            arr.put(
                JSONObject()
                    .put("id", e.title.id).put("name", e.title.name)
                    .put("year", e.title.year ?: "").put("poster", e.title.poster ?: "")
                    .put("provider", e.title.provider)
                    .put("status", e.status.name).put("pos", e.positionMs)
            )
        }
        prefs.edit().putString("tracker", arr.toString()).apply()
    }

    private fun same(a: Title, b: Title) = a.id == b.id && a.provider == b.provider

    fun set(t: Title, status: Status, positionMs: Long? = null) {
        val list = all().toMutableList()
        val i = list.indexOfFirst { same(it.title, t) }
        if (i >= 0) list[i] = list[i].copy(status = status, positionMs = positionMs ?: list[i].positionMs)
        else list.add(0, Entry(t, status, positionMs ?: 0L))
        save(list)
    }

    fun remove(t: Title) = save(all().filterNot { same(it.title, t) })
}
